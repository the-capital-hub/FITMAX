import { Link } from "react-router-dom";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import "./Pricing.css";

const options=[
  {tag:"START",title:"Assessment",sub:"Understand where you are starting",copy:"Begin with a professional assessment to understand your condition, goals and recovery direction.",items:["Initial assessment","Recovery goals","Personalized next steps","Care guidance"]},
  {tag:"RECOVER",title:"Guided Rehabilitation",sub:"Care built around your plan",copy:"Continue with structured rehabilitation designed around progress, exercises and clinical guidance.",items:["Personalized rehab plan","Guided exercises","Progress tracking","Regular check ins"]},
  {tag:"CONTINUE",title:"Ongoing Care",sub:"Support as your needs change",copy:"Stay connected as your recovery develops and your goals change over time.",items:["Follow up consultations","Plan adjustments","Progress review","Recovery guidance"]}
];

function Pricing(){
 return <div className="pr-page"><Navbar/><main>
  <section className="pr-hero"><div className="pr-container pr-hero-grid"><div><span className="pr-kicker">PRICING</span><h1>Care that is clear from the start.</h1><p>Your recovery should not feel complicated. FitMax pricing is designed around the care you need at each stage of rehabilitation.</p><Link to="/book-assessment" className="pr-button">Book an Assessment ↗</Link></div><div className="pr-hero-card"><small>RECOVERY IS PERSONAL</small><strong>Your plan should be personal too.</strong><p>Assessment comes first so the right care can be discussed around your condition and goals.</p><div>01&nbsp; Understand your needs</div><div>02&nbsp; Define the recovery direction</div><div>03&nbsp; Choose the right care</div></div></div></section>
  <section className="pr-options"><div className="pr-container"><span className="pr-label">CARE OPTIONS</span><h2>Choose the stage that fits your recovery.</h2><p className="pr-disclaimer">Final fees can vary by service, consultation format and care plan. Confirm current pricing before booking.</p><div className="pr-grid">{options.map((x,i)=><article className={`pr-plan ${i===1?"featured":""}`} key={x.title}><small>{x.tag}</small><h3>{x.title}</h3><b>{x.sub}</b><p>{x.copy}</p><hr/><ul>{x.items.map(item=><li key={item}>✓ {item}</li>)}</ul><Link to="/book-assessment">Discuss This Option ↗</Link></article>)}</div></div></section>
  <section className="pr-value"><div className="pr-container pr-split"><div><span className="pr-label">WHAT YOUR CARE SUPPORTS</span><h2>More than a single appointment.</h2></div><div className="pr-list">{["Assessment and understanding","Personalized rehabilitation","Guided exercise and consistency","Progress and plan adjustments"].map((x,i)=><div key={x}><b>0{i+1}</b><span>{x}</span></div>)}</div></div></section>
  <section className="pr-cta"><div className="pr-container"><span className="pr-kicker">START YOUR RECOVERY</span><h2>Let's understand where you are starting from.</h2><p>Book an assessment and take the first step towards a personalized recovery plan.</p><Link to="/book-assessment" className="pr-button light">Book an Assessment ↗</Link></div></section>
 </main><Footer/></div>
}
export default Pricing;
