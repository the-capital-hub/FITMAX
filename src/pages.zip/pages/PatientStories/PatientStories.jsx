import { Link } from "react-router-dom";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import "./PatientStories.css";

const journey = [
  ["01","Starting Point","Understand pain, movement, strength and the goals that matter."],
  ["02","Assessment","Build a clear picture of the condition and recovery direction."],
  ["03","Rehabilitation","Follow a personalized plan with guided exercises and clinical support."],
  ["04","Progress","Track consistency, symptoms, movement and milestones."],
  ["05","Return to Life","Work towards everyday activities, confidence and independence."]
];

function PatientStories() {
  return (
    <div className="ps-page">
      <Navbar />
      <main>
        <section className="ps-hero">
          <div className="ps-container ps-hero-grid">
            <div className="ps-hero-copy">
              <span className="ps-kicker">PATIENT STORIES</span>
              <h1>Every recovery has a story.</h1>
              <p>Recovery is personal. FitMax is built around the progress, goals and everyday moments that make getting better meaningful.</p>
              <div className="ps-actions">
                <Link to="/book-assessment" className="ps-btn ps-btn-primary">Start Your Recovery ↗</Link>
                <Link to="/how-it-works" className="ps-btn ps-btn-ghost">See How It Works</Link>
              </div>
            </div>
            <div className="ps-hero-media">
              <img src="https://images.pexels.com/photos/6111616/pexels-photo-6111616.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Illustrative physiotherapy session" />
              <span className="ps-image-tag">ILLUSTRATIVE IMAGE</span>
              <div className="ps-floating-card">
                <small>RECOVERY JOURNEY</small>
                <strong>Progress is built one step at a time.</strong>
                <span>Assessment · Rehabilitation · Progress</span>
              </div>
            </div>
          </div>
        </section>

        <section className="ps-intro">
          <div className="ps-container ps-split">
            <div>
              <span className="ps-kicker">THE FITMAX APPROACH</span>
              <h2>Recovery is more than reducing pain.</h2>
            </div>
            <div>
              <p>A meaningful recovery can include better movement, greater strength, renewed confidence and the ability to return to everyday life.</p>
              <div className="ps-mini-grid">
                <div><b>01</b><span>Move with confidence</span></div>
                <div><b>02</b><span>Build strength</span></div>
                <div><b>03</b><span>Return to routine</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="ps-feature-section">
          <div className="ps-container">
            <div className="ps-section-head">
              <div>
                <span className="ps-kicker">RECOVERY JOURNEYS</span>
                <h2>What a recovery journey can look like.</h2>
              </div>
              <p>These are illustrative journeys for the website experience. Real patient stories should be published only with appropriate consent.</p>
            </div>
            <div className="ps-feature">
              <div className="ps-feature-image">
                <img src="https://images.pexels.com/photos/6111616/pexels-photo-6111616.jpeg?auto=compress&cs=tinysrgb&w=1400" alt="Illustrative rehabilitation session" />
                <span>ILLUSTRATIVE IMAGE</span>
              </div>
              <div className="ps-feature-content">
                <small>EXAMPLE JOURNEY</small>
                <h3>Knee Rehabilitation</h3>
                <p>A structured knee recovery journey can move from understanding the starting point to rebuilding movement, strength and confidence.</p>
                <div className="ps-timeline">
                  {journey.map(([n,title,copy]) => (
                    <div key={n}>
                      <b>{n}</b>
                      <div><strong>{title}</strong><span>{copy}</span></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="ps-stories">
          <div className="ps-container">
            <span className="ps-kicker">MORE RECOVERY PATHS</span>
            <h2>Different goals. One focus: moving forward.</h2>
            <div className="ps-story-grid">
              <article>
                <div className="ps-story-image"><img src="https://images.pexels.com/photos/3768916/pexels-photo-3768916.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Illustrative sports rehabilitation" /><span>ILLUSTRATIVE IMAGE</span></div>
                <div className="ps-story-content"><small>EXAMPLE JOURNEY</small><h3>Sports Injury Recovery</h3><p>Restore movement, rebuild strength and gradually work towards desired activities.</p><Link to="/conditions/sports-injury">Explore This Path ↗</Link></div>
              </article>
              <article>
                <div className="ps-story-image"><img src="https://images.pexels.com/photos/6749777/pexels-photo-6749777.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Illustrative mobility rehabilitation" /><span>ILLUSTRATIVE IMAGE</span></div>
                <div className="ps-story-content"><small>EXAMPLE JOURNEY</small><h3>Mobility & Strength</h3><p>Build control, confidence, strength and independence around everyday movement.</p><Link to="/conditions/mobility-strength">Explore This Path ↗</Link></div>
              </article>
            </div>
          </div>
        </section>

        <section className="ps-voices">
          <div className="ps-container ps-split">
            <div><span className="ps-kicker">PATIENT VOICES</span><h2>Real stories belong to real people.</h2></div>
            <div className="ps-consent"><b>CONSENT FIRST</b><p>This space is reserved for patient experiences shared with permission. Published stories can show the starting point, rehabilitation, progress and outcome without promising the same result for every person.</p></div>
          </div>
        </section>

        <section className="ps-cta">
          <div className="ps-container">
            <span className="ps-kicker">YOUR STORY STARTS HERE</span>
            <h2>Ready to start your recovery?</h2>
            <p>Take the first step towards a clearer, more personalized recovery journey.</p>
            <Link to="/book-assessment" className="ps-btn ps-btn-primary">Book an Assessment ↗</Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
export default PatientStories;
