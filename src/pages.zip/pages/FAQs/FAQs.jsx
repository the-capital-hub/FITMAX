import {useState} from "react";
import {Link} from "react-router-dom";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import "./FAQs.css";

const faqs=[
["What is FitMax?","FitMax is a patient first physiotherapy and rehabilitation experience designed to support recovery from injuries, surgeries, accidents and movement related conditions."],
["Is FitMax only for online physiotherapy?","FitMax includes digital rehabilitation and online care, while also explaining when an in person assessment or clinical support may be appropriate."],
["What happens in an assessment?","The assessment is used to understand your current condition, movement, goals and recovery needs so the next steps can be discussed clearly."],
["Will I receive a personalized exercise plan?","Where appropriate, your physiotherapist can provide a rehabilitation plan with guided exercises and progress focused support."],
["How do I track my progress?","FitMax is designed around consistency and progress. Your rehabilitation experience can include exercise completion, symptoms, progress and regular check ins."],
["Can I contact my physiotherapist during rehabilitation?","The care experience is designed to support communication with your care team and allow questions or plan adjustments when needed."],
["How much does physiotherapy cost?","Pricing depends on the type of care, consultation and rehabilitation support required. Visit Pricing or contact FitMax for current details."],
["When should I seek in person care?","Some situations require direct clinical assessment. Your physiotherapist can guide you when an in person assessment is appropriate."]
];

function FAQs(){
 const [open,setOpen]=useState(0);
 return <div className="fq-page"><Navbar/><main>
  <section className="fq-hero"><div className="fq-container"><span>FREQUENTLY ASKED QUESTIONS</span><h1>Clarity before you start.</h1><p>Simple answers about FitMax, physiotherapy, rehabilitation and what your recovery journey can look like.</p></div></section>
  <section className="fq-main"><div className="fq-container fq-grid"><aside><small>FITMAX SUPPORT</small><h2>Questions are part of recovery.</h2><p>Understanding your care can help you take the next step with more confidence.</p><Link to="/book-assessment">Book an Assessment ↗</Link></aside><div className="fq-list">{faqs.map(([q,a],i)=><div className={`fq-item ${open===i?"open":""}`} key={q}><button type="button" onClick={()=>setOpen(open===i?-1:i)}><span><b>0{i+1}</b>{q}</span><i>{open===i?"−":"+"}</i></button><div><p>{a}</p></div></div>)}</div></div></section>
  <section className="fq-bottom"><div className="fq-container"><small>STILL NEED HELP?</small><h2>Let's talk about your recovery.</h2><Link to="/contact">Contact FitMax ↗</Link></div></section>
 </main><Footer/></div>
}
export default FAQs;
